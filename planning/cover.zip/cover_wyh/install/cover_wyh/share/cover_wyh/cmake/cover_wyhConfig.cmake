# generated from ament/cmake/core/templates/nameConfig.cmake.in

# prevent multiple inclusion
if(_cover_wyh_CONFIG_INCLUDED)
  # ensure to keep the found flag the same
  if(NOT DEFINED cover_wyh_FOUND)
    # explicitly set it to FALSE, otherwise CMake will set it to TRUE
    set(cover_wyh_FOUND FALSE)
  elseif(NOT cover_wyh_FOUND)
    # use separate condition to avoid uninitialized variable warning
    set(cover_wyh_FOUND FALSE)
  endif()
  return()
endif()
set(_cover_wyh_CONFIG_INCLUDED TRUE)

# output package information
if(NOT cover_wyh_FIND_QUIETLY)
  message(STATUS "Found cover_wyh: 0.0.1 (${cover_wyh_DIR})")
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "Package 'cover_wyh' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  # optionally quiet the deprecation message
  if(NOT ${cover_wyh_DEPRECATED_QUIET})
    message(DEPRECATION "${_msg}")
  endif()
endif()

# flag package as ament-based to distinguish it after being find_package()-ed
set(cover_wyh_FOUND_AMENT_PACKAGE TRUE)

# include all config extra files
set(_extras "")
foreach(_extra ${_extras})
  include("${cover_wyh_DIR}/${_extra}")
endforeach()
